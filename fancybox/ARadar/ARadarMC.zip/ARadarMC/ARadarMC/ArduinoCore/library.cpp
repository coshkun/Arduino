/*
 * ArduinoCore.cpp
 *
 * Created: 2.05.2017 02:54:07
 * Author : coskun
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

